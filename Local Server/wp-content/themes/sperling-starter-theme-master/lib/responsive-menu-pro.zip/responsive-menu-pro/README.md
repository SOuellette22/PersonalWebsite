[![Codeship Status for peter-featherstone/Responsive-Menu-Pro](https://app.codeship.com/projects/4ddb7260-4a8c-0137-db99-5e2db24b4609/status?branch=master)](https://app.codeship.com/projects/338582)

### Supported by BrowserStack
Thanks to [BrowserStack](https://browserstack.com/) for their support of this open-source project.

<img src="https://responsive.menu/wp-content/themes/responsive-menu/static/imgs/browserstacklogo.svg" width="150">