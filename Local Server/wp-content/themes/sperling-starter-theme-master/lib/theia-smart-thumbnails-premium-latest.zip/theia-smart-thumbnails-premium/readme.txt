=== Theia Smart Thumbnails ===
Requires at least: 3.4
Tested up to: 4.9
Requires PHP: 5.3