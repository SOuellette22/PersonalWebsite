<?php 
/*
 * Plugin Name:       Sperling Admin Client Role
* Description:       Create Client Admin role for Sperling Interactive sites, you can change these capabilites by editing the plugin
* Version:           1.0.0
* Author:            Sperling Interactive
*/

 
//// Create the Client Admin role by duplicating the Admin Role then removing certain capabiltiies
//// If you would like to give that capability back to the user role, delete it from the $caps array, and run it through add_cap
function sperling_add_client_admin_role ()
{
	global $wp_roles;
	if ( ! isset( $wp_roles ) ) $wp_roles = new WP_Roles();

	//Adding a admin role with all admin capabilitess, so we can hide certain capabilities
	$admin_capabilities = $wp_roles->get_role('administrator');
	$wp_roles->add_role('client_admin', 'Client Admin', $admin_capabilities->capabilities);

    $client_admin_role = get_role('client_admin');
    //// Don't allow the client to do the following.
    $caps = array(
        'activate_plugins',
        'edit_plugins',
        'update_plugins',
        'delete_plugins',
        'install_plugins',
        'resume_plugins',
        'switch_themes',
        'edit_themes',
        'update_themes',
        'install_themes',
        'delete_themes',
        'resume_themes',
        'frm_change_settings',
        'frm_edit_forms',
        'frm_delete_forms'
    );
    foreach ( $caps as $cap ) {
        // Remove the capability.
        $client_admin_role->remove_cap( $cap );
    } 
    //// Uncomment below and add the capability name and reload wp-admin a few times to give that capability back to the user role, don't forget to remove it from the above $caps array
    // $client_admin_role->add_cap('activate_plugins');
}


//// Hides wp-admin menu items for Client Admin Role
//// see https://developer.wordpress.org/reference/functions/remove_menu_page/ for more options
function hide_admin_pages_for_client_admin_role() {
    global $user_ID;
    $user = new WP_User( $user_ID );

    if ( in_array('client_admin', $user->roles) ) { //your user id
        //// Top Level Pages
        remove_menu_page('edit.php?post_type=acf-field-group'); // ACF
        remove_menu_page('wpseo_dashboard'); // Yoast
        remove_menu_page('litespeed'); // Litespeed
        remove_menu_page('smush'); // Smush
        remove_menu_page('wpmudev'); // WPMUDEV
        //// Submenu Pages
        remove_submenu_page('options-general.php','options-general.php'); // Settings > General
        remove_submenu_page('options-general.php','options-reading.php'); // Settings > Reading
        remove_submenu_page('options-general.php','options-writing.php'); // Settings > Writing
        remove_submenu_page('options-general.php','options-discussion.php'); // Settings > Discussion
        remove_submenu_page('options-general.php','options-permalink.php'); // Settings > Permalink
        remove_submenu_page('options-general.php','litespeed-cache-options'); // Settings > Litespeed
        
    }
}

//// Don't allow users with client_admin role to promote users to admin
function remove_admin_promotion($all_roles) {
    $user = wp_get_current_user();
    foreach ( $all_roles as $name => $role ) {
        if (in_array('client_admin', $user->roles)) {
            unset($all_roles['administrator']);
        }
    }
    return $all_roles;
}



add_action('init', 'sperling_add_client_admin_role'); //// Create the Client Admin Role
add_action( 'admin_init', 'hide_admin_pages_for_client_admin_role' ); //// Hide certain admin pages/screens from the Client Role
add_filter('editable_roles', 'remove_admin_promotion'); //// Don't allow users with client_admin role to promote users to admin